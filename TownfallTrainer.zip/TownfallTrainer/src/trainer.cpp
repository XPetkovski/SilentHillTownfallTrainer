// TownfallTrainer - config-driven external trainer for single-player use.
// Reads trainer.ini next to the exe. Supports two feature modes:
//   patch  : AOB-scan for an instruction and overwrite it (e.g. NOP a decrement)
//   cave   : AOB-scan, jump to allocated memory running custom bytes, jump back
//   freeze : follow a pointer chain and keep writing a value
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <cstring>

struct Feature {
    std::string section, name, hotkeyName, mode, status;
    int vk = 0;
    bool enabled = false, keyDown = false;
    // patch mode
    std::vector<int> pattern;
    long long patternOffset = 0;
    std::vector<uint8_t> patchBytes, original;
    uintptr_t patchAddr = 0;
    // cave mode
    int overwrite = 0;
    std::vector<uint8_t> caveBytes;
    uintptr_t caveAddr = 0;
    // freeze mode
    std::vector<int> basePattern;
    int ripDisp = -1, ripLen = 0;
    long long baseOffset = 0;
    bool hasBaseOffset = false;
    uintptr_t base = 0;
    std::vector<long long> offsets;
    std::string type = "float";
    double value = 0;
};

static HANDLE g_proc = nullptr;
static std::vector<Feature>* g_features = nullptr;

static std::string trim(std::string s) {
    size_t c = s.find(';');
    if (c != std::string::npos) s = s.substr(0, c);
    while (!s.empty() && isspace((unsigned char)s.back())) s.pop_back();
    size_t i = 0;
    while (i < s.size() && isspace((unsigned char)s[i])) ++i;
    return s.substr(i);
}
static std::string lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return (char)tolower(c); });
    return s;
}
static std::string upper(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return (char)toupper(c); });
    return s;
}
static std::string ini(const std::string& file, const std::string& sec, const char* key, const char* def = "") {
    char buf[4096];
    GetPrivateProfileStringA(sec.c_str(), key, def, buf, sizeof(buf), file.c_str());
    return trim(buf);
}
static std::vector<int> parsePattern(const std::string& s) {
    std::vector<int> out;
    std::istringstream ss(s);
    std::string tok;
    while (ss >> tok) {
        if (tok == "?" || tok == "??" || tok == "*") out.push_back(-1);
        else out.push_back((int)strtoul(tok.c_str(), nullptr, 16) & 0xFF);
    }
    return out;
}
static std::vector<long long> parseOffsets(const std::string& s) {
    std::vector<long long> out;
    std::string tok;
    std::istringstream ss(s);
    while (std::getline(ss, tok, ',')) {
        tok = trim(tok);
        if (!tok.empty()) out.push_back(strtoll(tok.c_str(), nullptr, 0));
    }
    return out;
}
static int parseKey(std::string k) {
    k = upper(k);
    if (k.empty()) return 0;
    if (k[0] == 'F' && k.size() > 1 && isdigit((unsigned char)k[1])) {
        int n = atoi(k.c_str() + 1);
        if (n >= 1 && n <= 24) return VK_F1 + n - 1;
    }
    if (k.rfind("NUMPAD", 0) == 0 && k.size() == 7 && isdigit((unsigned char)k[6])) return VK_NUMPAD0 + (k[6] - '0');
    if (k == "INSERT") return VK_INSERT;
    if (k == "DELETE") return VK_DELETE;
    if (k == "HOME") return VK_HOME;
    if (k == "END") return VK_END;
    if (k == "PAGEUP") return VK_PRIOR;
    if (k == "PAGEDOWN") return VK_NEXT;
    if (k.size() == 1 && isalnum((unsigned char)k[0])) return (unsigned char)k[0];
    return 0;
}

static DWORD findProcess(const std::string& needle, std::string& exeName) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    PROCESSENTRY32 pe{}; pe.dwSize = sizeof(pe);
    DWORD pid = 0;
    std::string n = lower(needle);
    if (Process32First(snap, &pe)) {
        do {
            if (lower(pe.szExeFile).find(n) != std::string::npos) {
                pid = pe.th32ProcessID; exeName = pe.szExeFile; break;
            }
        } while (Process32Next(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}
static bool findModule(DWORD pid, const std::string& name, uintptr_t& base, size_t& size) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
    if (snap == INVALID_HANDLE_VALUE) return false;
    MODULEENTRY32 me{}; me.dwSize = sizeof(me);
    bool ok = false;
    std::string n = lower(name);
    if (Module32First(snap, &me)) {
        do {
            if (lower(me.szModule) == n) {
                base = (uintptr_t)me.modBaseAddr; size = me.modBaseSize; ok = true; break;
            }
        } while (Module32Next(snap, &me));
    }
    CloseHandle(snap);
    return ok;
}

// Returns number of matches (capped at 2); first match in out.
static int scan(uintptr_t start, size_t size, const std::vector<int>& pat, uintptr_t& out) {
    if (pat.empty()) return 0;
    int found = 0;
    uintptr_t addr = start, end = start + size;
    std::vector<uint8_t> buf;
    while (addr < end) {
        MEMORY_BASIC_INFORMATION mbi;
        if (!VirtualQueryEx(g_proc, (LPCVOID)addr, &mbi, sizeof(mbi))) break;
        uintptr_t rend = (uintptr_t)mbi.BaseAddress + mbi.RegionSize;
        if (rend > end) rend = end;
        bool readable = mbi.State == MEM_COMMIT && !(mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS));
        if (readable && rend > addr) {
            size_t len = rend - addr;
            buf.resize(len);
            SIZE_T got = 0;
            if (ReadProcessMemory(g_proc, (LPCVOID)addr, buf.data(), len, &got) && got >= pat.size()) {
                for (size_t i = 0; i + pat.size() <= got; ++i) {
                    bool m = true;
                    for (size_t j = 0; j < pat.size(); ++j)
                        if (pat[j] >= 0 && buf[i + j] != (uint8_t)pat[j]) { m = false; break; }
                    if (m) {
                        if (found == 0) out = addr + i;
                        if (++found >= 2) return found;
                    }
                }
            }
        }
        addr = rend;
    }
    return found;
}

template <typename T> static bool rd(uintptr_t a, T& v) {
    SIZE_T n = 0;
    return ReadProcessMemory(g_proc, (LPCVOID)a, &v, sizeof(T), &n) && n == sizeof(T);
}
static bool wr(uintptr_t a, const void* data, size_t len, bool code) {
    DWORD oldProt = 0;
    if (code) VirtualProtectEx(g_proc, (LPVOID)a, len, PAGE_EXECUTE_READWRITE, &oldProt);
    SIZE_T n = 0;
    bool ok = WriteProcessMemory(g_proc, (LPVOID)a, data, len, &n) && n == len;
    if (code) {
        DWORD tmp;
        VirtualProtectEx(g_proc, (LPVOID)a, len, oldProt, &tmp);
        FlushInstructionCache(g_proc, (LPCVOID)a, len);
    }
    return ok;
}
static uintptr_t resolveChain(const Feature& f) {
    uintptr_t addr = f.base;
    for (long long off : f.offsets) {
        uintptr_t p = 0;
        if (!rd(addr, p) || !p) return 0;
        addr = p + (uintptr_t)off;
    }
    return addr;
}
static void writeValue(uintptr_t a, const Feature& f) {
    if (f.type == "int")         { int32_t v = (int32_t)f.value; wr(a, &v, sizeof v, false); }
    else if (f.type == "int64")  { int64_t v = (int64_t)f.value; wr(a, &v, sizeof v, false); }
    else if (f.type == "byte")   { uint8_t v = (uint8_t)f.value; wr(a, &v, sizeof v, false); }
    else if (f.type == "double") { double v = f.value; wr(a, &v, sizeof v, false); }
    else                         { float v = (float)f.value; wr(a, &v, sizeof v, false); }
}

// Allocate executable memory within +/-2GB of target so a 5-byte rel32 jmp can reach it.
static uintptr_t allocNear(uintptr_t target, size_t size) {
    SYSTEM_INFO si; GetSystemInfo(&si);
    const uintptr_t gran = si.dwAllocationGranularity;
    const uintptr_t range = 0x7FF00000;
    uintptr_t start = target & ~(gran - 1);
    for (int dir = -1; dir <= 1; dir += 2) {
        for (uintptr_t step = gran; step < range; step += gran) {
            uintptr_t a = dir < 0 ? start - step : start + step;
            if (dir < 0 && step >= start) break;
            MEMORY_BASIC_INFORMATION mbi;
            if (!VirtualQueryEx(g_proc, (LPCVOID)a, &mbi, sizeof mbi)) continue;
            if (mbi.State != MEM_FREE) continue;
            void* p = VirtualAllocEx(g_proc, (LPVOID)a, size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
            if (p) return (uintptr_t)p;
        }
    }
    return 0;
}
static bool jmpRel32(uintptr_t from, uintptr_t to, uint8_t out[5]) {
    long long rel = (long long)to - (long long)(from + 5);
    if (rel < INT32_MIN || rel > INT32_MAX) return false;
    int32_t r = (int32_t)rel;
    out[0] = 0xE9; memcpy(out + 1, &r, 4);
    return true;
}
// Writes the cave (custom bytes + jmp back) and prepares patchBytes (jmp to cave + NOPs).
static bool prepareCave(Feature& f) {
    if (!f.caveAddr) {
        f.caveAddr = allocNear(f.patchAddr, 4096);
        if (!f.caveAddr) { f.status = "cave alloc failed"; return false; }
    }
    std::vector<uint8_t> cave = f.caveBytes;
    uint8_t j[5];
    if (!jmpRel32(f.caveAddr + cave.size(), f.patchAddr + f.overwrite, j)) { f.status = "cave out of range"; return false; }
    cave.insert(cave.end(), j, j + 5);
    if (!wr(f.caveAddr, cave.data(), cave.size(), true)) { f.status = "cave write failed"; return false; }
    if (!jmpRel32(f.patchAddr, f.caveAddr, j)) { f.status = "cave out of range"; return false; }
    f.patchBytes.assign(j, j + 5);
    f.patchBytes.resize(f.overwrite, 0x90);
    return true;
}

static void setPatch(Feature& f, bool on) {
    if (!f.patchAddr) return;
    if (on) {
        if (f.mode == "cave" && !prepareCave(f)) return;
        f.original.resize(f.patchBytes.size());
        SIZE_T n = 0;
        if (!ReadProcessMemory(g_proc, (LPCVOID)f.patchAddr, f.original.data(), f.original.size(), &n)) {
            f.status = "read failed"; return;
        }
        f.enabled = wr(f.patchAddr, f.patchBytes.data(), f.patchBytes.size(), true);
        if (!f.enabled) f.status = "write failed";
    } else {
        if (!f.original.empty()) wr(f.patchAddr, f.original.data(), f.original.size(), true);
        f.enabled = false;
    }
}
static void restoreAll() {
    if (!g_features || !g_proc) return;
    for (auto& f : *g_features)
        if ((f.mode == "patch" || f.mode == "cave") && f.enabled) setPatch(f, false);
}
static BOOL WINAPI ctrlHandler(DWORD) { restoreAll(); return FALSE; }

static std::vector<Feature> loadFeatures(const std::string& file) {
    std::vector<Feature> out;
    char names[16384];
    DWORD len = GetPrivateProfileSectionNamesA(names, sizeof(names), file.c_str());
    for (char* p = names; p < names + len && *p; p += strlen(p) + 1) {
        std::string sec = p;
        if (lower(sec) == "general") continue;
        Feature f;
        f.section = sec;
        f.name = ini(file, sec, "Name", sec.c_str());
        f.hotkeyName = ini(file, sec, "Hotkey");
        f.vk = parseKey(f.hotkeyName);
        f.mode = lower(ini(file, sec, "Mode", "patch"));
        if (f.mode == "patch") {
            f.pattern = parsePattern(ini(file, sec, "Pattern"));
            f.patternOffset = strtoll(ini(file, sec, "Offset", "0").c_str(), nullptr, 0);
            for (int b : parsePattern(ini(file, sec, "Patch"))) f.patchBytes.push_back((uint8_t)(b < 0 ? 0x90 : b));
        } else if (f.mode == "cave") {
            f.pattern = parsePattern(ini(file, sec, "Pattern"));
            f.patternOffset = strtoll(ini(file, sec, "Offset", "0").c_str(), nullptr, 0);
            f.overwrite = atoi(ini(file, sec, "Overwrite", "0").c_str());
            for (int b : parsePattern(ini(file, sec, "Cave"))) f.caveBytes.push_back((uint8_t)(b < 0 ? 0x90 : b));
        } else {
            f.basePattern = parsePattern(ini(file, sec, "BasePattern"));
            std::string rd_ = ini(file, sec, "RipDispOffset");
            if (!rd_.empty()) f.ripDisp = atoi(rd_.c_str());
            f.ripLen = atoi(ini(file, sec, "RipInstrLen", "0").c_str());
            std::string bo = ini(file, sec, "BaseOffset");
            if (!bo.empty()) { f.baseOffset = strtoll(bo.c_str(), nullptr, 0); f.hasBaseOffset = true; }
            f.offsets = parseOffsets(ini(file, sec, "Offsets"));
            f.type = lower(ini(file, sec, "Type", "float"));
            f.value = atof(ini(file, sec, "Value", "0").c_str());
        }
        out.push_back(f);
    }
    return out;
}

static void resolveFeature(Feature& f, uintptr_t modBase, size_t modSize) {
    if (!f.vk) { f.status = "bad/missing Hotkey"; return; }
    if (f.mode == "patch" || f.mode == "cave") {
        if (f.pattern.empty() || (f.mode == "patch" ? f.patchBytes.empty() : f.caveBytes.empty())) { f.status = "not configured"; return; }
        if (f.mode == "cave" && f.overwrite < 5) { f.status = "Overwrite must be >= 5"; return; }
        uintptr_t hit = 0;
        int n = scan(modBase, modSize, f.pattern, hit);
        if (!n) { f.status = "pattern not found"; return; }
        f.patchAddr = hit + (uintptr_t)f.patternOffset;
        char b[96]; snprintf(b, sizeof b, "ready @ %p%s", (void*)f.patchAddr, n > 1 ? " (WARNING: pattern not unique)" : "");
        f.status = b;
    } else if (f.mode == "freeze") {
        if (!f.basePattern.empty()) {
            uintptr_t hit = 0;
            int n = scan(modBase, modSize, f.basePattern, hit);
            if (!n) { f.status = "base pattern not found"; return; }
            if (f.ripDisp >= 0) {
                int32_t disp = 0;
                if (!rd(hit + f.ripDisp, disp)) { f.status = "rip read failed"; return; }
                f.base = hit + f.ripLen + disp;
            } else f.base = hit;
            if (n > 1) { f.status = "ready (WARNING: base pattern not unique)"; return; }
        } else if (f.hasBaseOffset) {
            f.base = modBase + (uintptr_t)f.baseOffset;
        } else { f.status = "not configured"; return; }
        f.status = "ready";
    } else f.status = "unknown Mode";
}

static void draw(const std::vector<Feature>& fs, const std::string& exe, const std::string& exitKey) {
    system("cls");
    printf("  Townfall Trainer  |  attached to %s\n", exe.c_str());
    printf("  ------------------------------------------------------------\n");
    for (auto& f : fs)
        printf("  [%-8s] %-22s %-4s  %s\n", f.hotkeyName.c_str(), f.name.c_str(), f.enabled ? "ON" : "off", f.status.c_str());
    printf("\n  %s = restore patches and quit\n", exitKey.c_str());
}

int main() {
    char path[MAX_PATH];
    GetModuleFileNameA(nullptr, path, MAX_PATH);
    std::string dir = path;
    dir = dir.substr(0, dir.find_last_of("\\/") + 1);
    std::string file = dir + "trainer.ini";
    if (GetFileAttributesA(file.c_str()) == INVALID_FILE_ATTRIBUTES) {
        printf("trainer.ini not found next to the exe:\n  %s\n", file.c_str());
        system("pause"); return 1;
    }
    std::string procNeedle = ini(file, "General", "Process", "Townfall");
    std::string moduleName = ini(file, "General", "Module");
    std::string exitKeyName = ini(file, "General", "ExitKey", "END");
    int exitVk = parseKey(exitKeyName);
    int interval = atoi(ini(file, "General", "FreezeIntervalMs", "50").c_str());
    if (interval < 5) interval = 5;
    SetConsoleCtrlHandler(ctrlHandler, TRUE);

    for (;;) {
        printf("Waiting for a process matching \"%s\"... (start the game)\n", procNeedle.c_str());
        std::string exe;
        DWORD pid;
        while (!(pid = findProcess(procNeedle, exe))) {
            if (exitVk && (GetAsyncKeyState(exitVk) & 0x8000)) return 0;
            Sleep(1000);
        }
        Sleep(3000); // let the game finish mapping modules
        g_proc = OpenProcess(PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION |
                             PROCESS_QUERY_INFORMATION | SYNCHRONIZE, FALSE, pid);
        if (!g_proc) { printf("OpenProcess failed (%lu). Run as administrator.\n", GetLastError()); system("pause"); return 1; }
        uintptr_t modBase = 0; size_t modSize = 0;
        std::string mod = moduleName.empty() ? exe : moduleName;
        if (!findModule(pid, mod, modBase, modSize)) {
            printf("Module %s not found.\n", mod.c_str()); system("pause"); return 1;
        }
        std::vector<Feature> features = loadFeatures(file);
        g_features = &features;
        printf("Scanning %s (%zu MB)...\n", mod.c_str(), modSize >> 20);
        for (auto& f : features) resolveFeature(f, modBase, modSize);
        draw(features, exe, exitKeyName);

        bool exitDown = true; // ignore a key already held at startup
        for (;;) {
            if (WaitForSingleObject(g_proc, 0) == WAIT_OBJECT_0) break;
            bool dirty = false;
            for (auto& f : features) {
                bool down = f.vk && (GetAsyncKeyState(f.vk) & 0x8000);
                if (down && !f.keyDown && f.status.rfind("ready", 0) == 0) {
                    if (f.mode == "patch" || f.mode == "cave") setPatch(f, !f.enabled);
                    else f.enabled = !f.enabled;
                    Beep(f.enabled ? 880 : 440, 80);
                    dirty = true;
                }
                f.keyDown = down;
                if (f.mode == "freeze" && f.enabled) {
                    uintptr_t a = resolveChain(f);
                    if (a) writeValue(a, f); // null chain = not in gameplay yet, skip quietly
                }
            }
            bool ed = exitVk && (GetAsyncKeyState(exitVk) & 0x8000);
            if (ed && !exitDown) { restoreAll(); CloseHandle(g_proc); return 0; }
            exitDown = ed;
            if (dirty) draw(features, exe, exitKeyName);
            Sleep(interval);
        }
        printf("Game closed.\n");
        g_features = nullptr;
        CloseHandle(g_proc); g_proc = nullptr;
    }
}
